// "use strict"
// import { ButtonComponent } from "../../components/button/index.js";
// import { ProductCardComponent } from "../../components/product-card/index.js";
// import { ProductPage } from "../product/index.js";

// export class MainPage {
//     constructor(parent) {
//         this.parent = parent;
//         this.latestID = 1;
//     }

//     get pageRoot() {
//         return document.getElementById('main-page');
//     }

//     getHTML() {
//         return (
//             `
//                 <div id="main-page" class="d-flex flex-wrap"></div>
//             `
//         );
//     }

//     render() {
//         this.parent.innerHTML = '';
//         const html = this.getHTML();
//         this.parent.insertAdjacentHTML('beforeend', html);

//         fetch('http://localhost:8000/stocks')
//             .then((res) => res.json())
//             .then((data) => {
//                 data.forEach((item) => {
//                     const productCard = new ProductCardComponent(this.pageRoot);
//                     if (item.title === 'Калькулятор')
//                         productCard.render(item, this.clickCalc.bind(this), this.delCard.bind(this));
//                     else
//                         productCard.render(item, this.clickCard.bind(this), this.delCard.bind(this));
//                     this.latestID = item.id + 1;
//                 });
//             });

//         // Button for adding new cards
//         const btn = new ButtonComponent(this.parent, 'ДОБАВИТЬ Машину');
//         btn.render(this.addNewCard.bind(this));

//         // Button for adding new cars
//         const btnCar = new ButtonComponent(this.parent, 'ДОБАВИТЬ бабочку');
//         btnCar.render(this.addNewCarImage.bind(this));
//     }

//     clickCard(e) {
//         const cardId = e.target.dataset.id;

//         const productPage = new ProductPage(this.parent, cardId);
//         productPage.render();
//     }

//     clickCalc() {
//         open('pages/calc/main.html', '_self');
//     }

//     delCard(id) {
//         fetch(`http://localhost:8000/stocks/${id}`, { method: 'DELETE' });
//     }

//     addNewCard() {
//         if (!document.stats) {
//             document.stats = {};
//         }
//         document.stats[this.latestID] = 1;

//         const UNSPLASH_ACCESS_KEY = 'i5sCuEI94h9nAE-xOZWAqp3wXTbX31lRWsGpLiD4Y6w';

//         fetch(`https://api.unsplash.com/photos/random?collections=C_RVzE7LBQc&client_id=${UNSPLASH_ACCESS_KEY}`)
//             .then((res) => {
//                 if (!res.ok) {
//                     throw new Error(`HTTP error! Status: ${res.status}`);
//                 }
//                 return res.json();
//             })
//             .then((data) => {
//                 fetch('http://localhost:8000/stocks', {
//                     method: 'POST',
//                     headers: {
//                         'Accept': 'application/json',
//                         'Content-Type': 'application/json'
//                     },
//                     body: JSON.stringify({
//                         id: this.latestID,
//                         src: data.urls.regular,
//                         title: 'Гора ' + this.latestID,
//                         text: 'Такой горы вы ещё не видели! ' + this.latestID,
//                     })
//                 });
//             })
//             .catch(error => {
//                 console.error('Error fetching image from Unsplash:', error);
//             });
//     }

//     addNewCarImage() {
//         if (!document.stats) {
//             document.stats = {};
//         }
//         document.stats[this.latestID] = 1;

//         const UNSPLASH_ACCESS_KEY = 'i5sCuEI94h9nAE-xOZWAqp3wXTbX31lRWsGpLiD4Y6w';

//         fetch(`https://api.unsplash.com/photos/random?query=chairs&client_id=${UNSPLASH_ACCESS_KEY}`)
//             .then((res) => {
//                 if (!res.ok) {
//                     throw new Error(`HTTP error! Status: ${res.status}`);
//                 }
//                 return res.json();
//             })
//             .then((data) => {
//                 fetch('http://localhost:8000/stocks', {
//                     method: 'POST',
//                     headers: {
//                         'Accept': 'application/json',
//                         'Content-Type': 'application/json'
//                     },
//                     body: JSON.stringify({
//                         id: this.latestID,
//                         src: data.urls.regular,
//                         title: 'Стул ' + this.latestID,
//                         text: 'Такого стула вы ещё не видели! ' + this.latestID,
//                     })
//                 });
//             })
//             .catch(error => {
//                 console.error('Error fetching image from Unsplash:', error);
//             });
//     }
// }










"use strict"
import { ButtonComponent } from "../../components/button/index.js";
import { ProductCardComponent } from "../../components/product-card/index.js";
import { ProductPage } from "../product/index.js";

export class MainPage {
    constructor(parent) {
        this.parent = parent;
        this.latestID = 1;
        this.apiKey = 'a9f278b139354644b8b04903243005'; // Вставьте ваш API-ключ WeatherAPI здесь

        this.handleFormSubmit = this.handleFormSubmit.bind(this); // Привязываем контекст
    }

    get pageRoot() {
        return document.getElementById('main-page');
    }

    getHTML() {
        return (
            `
                <div id="main-page" class="d-flex flex-wrap">
                    <form id="weather-form">
                        <label for="date">Enter Date:</label>
                        <input type="date" id="date" name="date" required>
                        <button type="submit">Get Weather</button>
                    </form>
                    <div id="weather-result"></div>
                </div>
            `
        );
    }

    render() {
        this.parent.innerHTML = '';
        const html = this.getHTML();
        this.parent.insertAdjacentHTML('beforeend', html);

        fetch('http://localhost:8000/stocks')
            .then((res) => res.json())
            .then((data) => {
                data.forEach((item) => {
                    const productCard = new ProductCardComponent(this.pageRoot);
                    if (item.title === 'Калькулятор')
                        productCard.render(item, this.clickCalc.bind(this), this.delCard.bind(this));
                    else
                        productCard.render(item, this.clickCard.bind(this), this.delCard.bind(this));
                    this.latestID = item.id + 1;
                });
            });

        // Button for adding new cards
        const btn = new ButtonComponent(this.parent, 'ДОБАВИТЬ Машину');
        btn.render(this.addNewCard.bind(this));

        // Button for adding new cars
        const btnCar = new ButtonComponent(this.parent, 'ДОБАВИТЬ бабочку');
        btnCar.render(this.addNewCarImage.bind(this));

        // Register event listener for weather form
        const form = document.getElementById('weather-form');
        form.addEventListener('submit', this.handleFormSubmit);
    }

    clickCard(e) {
        const cardId = e.target.dataset.id;

        const productPage = new ProductPage(this.parent, cardId);
        productPage.render();
    }

    clickCalc() {
        open('pages/calc/main.html', '_self');
    }

    delCard(id) {
        fetch(`http://localhost:8000/stocks/${id}`, { method: 'DELETE' });
    }

    addNewCard() {
        if (!document.stats) {
            document.stats = {};
        }
        document.stats[this.latestID] = 1;

        const UNSPLASH_ACCESS_KEY = 'i5sCuEI94h9nAE-xOZWAqp3wXTbX31lRWsGpLiD4Y6w';

        fetch(`https://api.unsplash.com/photos/random?collections=C_RVzE7LBQc&client_id=${UNSPLASH_ACCESS_KEY}`)
            .then((res) => {
                if (!res.ok) {
                    throw new Error(`HTTP error! Status: ${res.status}`);
                }
                return res.json();
            })
            .then((data) => {
                fetch('http://localhost:8000/stocks', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: this.latestID,
                        src: data.urls.regular,
                        title: 'Гора ' + this.latestID,
                        text: 'Такой горы вы ещё не видели! ' + this.latestID,
                    })
                });
            })
            .catch(error => {
                console.error('Error fetching image from Unsplash:', error);
            });
    }

    addNewCarImage() {
        if (!document.stats) {
            document.stats = {};
        }
        document.stats[this.latestID] = 1;

        const UNSPLASH_ACCESS_KEY = 'i5sCuEI94h9nAE-xOZWAqp3wXTbX31lRWsGpLiD4Y6w';

        fetch(`https://api.unsplash.com/photos/random?query=chairs&client_id=${UNSPLASH_ACCESS_KEY}`)
            .then((res) => {
                if (!res.ok) {
                    throw new Error(`HTTP error! Status: ${res.status}`);
                }
                return res.json();
            })
            .then((data) => {
                fetch('http://localhost:8000/stocks', {
                    method: 'POST',
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        id: this.latestID,
                        src: data.urls.regular,
                        title: 'Стул ' + this.latestID,
                        text: 'Такого стула вы ещё не видели! ' + this.latestID,
                    })
                });
            })
            .catch(error => {
                console.error('Error fetching image from Unsplash:', error);
            });
    }

    handleFormSubmit(event) {
        event.preventDefault();
        const date = document.getElementById('date').value;
        this.getWeather(date);
    }

    getWeather(date) {
        const url = `https://api.weatherapi.com/v1/history.json?key=${this.apiKey}&q=Moscow&dt=${date}`;

        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                this.displayWeather(data, date);
            })
            .catch(error => {
                console.error('Error fetching weather data:', error);
            });
    }

    displayWeather(data, date) {
        const weatherResult = document.getElementById('weather-result');
        weatherResult.innerHTML = '';

        if (data && data.forecast && data.forecast.forecastday[0]) {
            const weather = data.forecast.forecastday[0].day;
            weatherResult.innerHTML = `
                <h2>Weather for ${date}</h2>
                <p>Temperature: ${weather.avgtemp_c}°C</p>
                <p>Condition: ${weather.condition.text}</p>
            `;
        } else {
            weatherResult.innerHTML = '<p>No weather data available for this date.</p>';
        }
    }
}


