export const ID = 225342715
export const accessToken = 'vk1.a.qy4dvplEZNXeCmrK--at1l4uP4JhTwUid1Y0ozCCFJSBLWMU5EOEhpP4syH9lJrtqenzuwYK0-3sVQEFC29QObOCm6ZvJNS7TEbtdfxTRNQXJ--USgrgjsYYpQlTX-hjJJaTIPARbM_9U6A4Vlp-a4o5IjbvOdMsL05yKicIF5LMPRCwx0euzIb0O0GhaWiZVBpfGaH4zqvyMS4rs1FmoA'
export const version = '5.131'
