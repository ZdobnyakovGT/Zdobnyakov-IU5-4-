export class ProductCardComponent {
    constructor(parent) {
        this.parent = parent;
    }

    getHTML(data, name) {

        return `
                <div class="card" style="width: 300px;">
                    <img class="card-img-top" src="${data.photo_400_orig}" alt="картинка">
                    <div class="card-body">
                        <h5 class="card-title">${data.first_name} ${data.last_name}</h5>
                        <h5 class="card-title">${name}</h5>
                        <button class="btn btn-primary" id="click-card-${data.id}" data-id="${data.id}">Нажми на меня</button>
                    </div>
                </div>
            `;
    }

    addListeners(data, listener) {
        document
            .getElementById(`click-card-${data.id}`)
            .addEventListener("click", listener);
    }
    
    getData() {
        ajax.post(urls.getUserInfo(this.id), (data) => {
            this.renderData(data.response);
        });
    }
    renderData(item) {
        const product = new ProductComponent(this.pageRoot);
        product.render(item[0]);
    }

    render(data, name, listener) {
        const html = this.getHTML(data, name);
        this.parent.insertAdjacentHTML("beforeend", html);
        this.addListeners(data, listener);
    }
}
